package primeiraQuestao;

public class TestaRetangulo {

	public static void main(String[] args) {

		Retangulo retangulo = new Retangulo(5, 2);
		System.out.println(retangulo);

	}

}
