package terceiraQuestao;

import java.time.LocalDate;

public class Aluno {

	private String nome;
	private int anoIngresso;
	private String curso;
	private int quantidadeDisciplinasAprovadas;
	
	public Aluno(String nome, int anoIngresso, String curso, int quantidadeDisciplinasAprovadas) {
		this.nome = nome;
		this.anoIngresso = anoIngresso;
		this.curso = curso;
		this.quantidadeDisciplinasAprovadas = quantidadeDisciplinasAprovadas;
	}
	
	public int calculaCredito() {
		return 0;
	}
	
}
