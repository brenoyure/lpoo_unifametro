package segundaQuestao;

/**
 * Calcular Quantidade de Alimento por dia Mam�fero 2kg/dia Ave 100g/dia Peixe
 * 20g/dia
 */

public class Animal {

	private String tipo;
	private String nome;
	private int idade;
	private double qtdAlimentoPorAno;

	public Animal(String tipo, String nome, int idade) {
		this.tipo = tipo;
		this.nome = nome;
		this.idade = idade;
		this.calculaQuantidadePorAno(tipo);
	}

	public double calculaQuantidadePorAno(String tipo) {
		switch (tipo) {
		case "Mam�fero": {
			return this.qtdAlimentoPorAno = 2.0 * this.idade;
		}

		case "Ave": {
			return this.qtdAlimentoPorAno = 0.1 * this.idade;
		}

		case "Peixe": {
			return this.qtdAlimentoPorAno = 0.02 * this.idade;
		}

		default:
			throw new IllegalArgumentException("Tipo n�o existente: " + tipo);
		}

	}

	@Override
	public String toString() {
		return "Animal [Tipo=" + tipo + ", Nome=" + nome + ", Idade=" + idade + ", Quantidade de Alimento por Ano="
				+ qtdAlimentoPorAno + "]";
	}

}
