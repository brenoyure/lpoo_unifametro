package segundaQuestao;

public class TestaAnimal {

	public static void main(String[] args) {
		
		Animal animal = new Animal("Mam�fero", "C�o", 4);
		Animal animal1 = new Animal("Ave", "Papagaio", 2);
		Animal nemo = new Animal("Peixe", "Nemo", 14);
		
		System.out.println(animal);
		System.out.println(animal1);
		System.out.println(nemo);
		
	}
	
}
