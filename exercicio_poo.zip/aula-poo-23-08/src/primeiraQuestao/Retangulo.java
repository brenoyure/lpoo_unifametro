package primeiraQuestao;

public class Retangulo {

	private float comprimento;
	private float largura;
	private float area;
	private int perimetro;

	public Retangulo(int lado, int altura) {
		this.comprimento = lado;
		this.largura = altura;
		this.perimetro = calculaPerimetro(lado, altura);
		this.area = calculaArea(altura, lado);
	}
	
	public float calculaArea(int altura, int lado) {
		return this.area = altura * this.comprimento;
	}
	
	public int calculaPerimetro(int lado, int altura) {
		return this.perimetro = (lado * 2) + (altura * 2);
	}

	@Override
	public String toString() {
		return "Retangulo [Comprimento=" + this.comprimento + "cm, Largura=" + this.largura + "cm, área=" + this.area + "cm, Perímetro=" + this.perimetro + "cm]";
	}
	
}
