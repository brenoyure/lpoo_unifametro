package segundaQuestao;

public class TestaAnimal {

	public static void main(String[] args) {
		
		Animal animal1 = new Animal("Mamífero", "Cão", 4);
		Animal animal2 = new Animal("Ave", "Papagaio", 2);
		Animal animal3 = new Animal("Peixe", "Nemo", 14);
		
		System.out.println(animal1);
		System.out.println(animal2);
		System.out.println(animal3);
		
	}
	
}
