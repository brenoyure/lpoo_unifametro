package segundaQuestao;

/**
 * Calcular Quantidade de Alimento por dia Mamífero 2kg/dia Ave 100g/dia Peixe
 * 20g/dia
 */

public class Animal {

	private String tipo;
	private String nome;
	private int idade;
	private double qtdAlimentoPorAno;

	public Animal(String tipo, String nome, int idade) {
		this.tipo = tipo;
		this.nome = nome;
		this.idade = idade;
		this.calculaQuantidadePorAno(tipo);
	}

	public double calculaQuantidadePorAno(String tipo) {
		switch (tipo) {
		case "Mamífero": {
			return this.qtdAlimentoPorAno = 2.0 * (365 * this.idade);
		}

		case "Ave": {
			return this.qtdAlimentoPorAno = 0.1 * (365 * this.idade);
		}

		case "Peixe": {
			return this.qtdAlimentoPorAno = 0.02 * (365 * this.idade);
		}

		default:
			throw new IllegalArgumentException("Tipo não existente: " + tipo);
		}

	}

	@Override
	public String toString() {
		return "Animal [Tipo=" + tipo + ", Nome=" + nome + ", Idade=" + idade + ", Quantidade de Alimento por Ano="
				+ qtdAlimentoPorAno + "]";
	}

}
