package terceiraQuestao;

public class TestaAluno {

	public static void main(String[] args) {

		Aluno a1 = new Aluno("Breno Yuri", 2020, "SI", 12);
		Aluno a2 = new Aluno("Inácio da Paz", 2021, "ADS", 5);
		Aluno a3 = new Aluno("Thiago Silva", 2019, "Redes", 21);
		Aluno a4 = new Aluno("Amanda Lacerda", 2018, "SI", 10);

		System.out.println(a1);
		System.out.println(a2);
		System.out.println(a3);
		System.out.println(a4);

	}

}
