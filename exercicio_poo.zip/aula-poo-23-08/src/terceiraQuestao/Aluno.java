package terceiraQuestao;

import java.time.LocalDate;

public class Aluno {

	private String nome;						// Nome do Aluno
	private int anoIngresso;					// Ano de Ingresso
	private String curso;						// Nome do Curso
	private int quantidadeDisciplinasAprovadas; // Quantidade de Disciplinas Aprovadas
	private int quantidadeDeCreditos;           // Quantidade de Créditos
	private int tempoPermanencia;				// Tempo de Permanência em Anos.
	
	public Aluno(String nome, int anoIngresso, String curso, int quantidadeDisciplinasAprovadas) {
		this.nome = nome;
		this.anoIngresso = anoIngresso;
		this.curso = curso;
		this.quantidadeDisciplinasAprovadas = quantidadeDisciplinasAprovadas;
		this.quantidadeDeCreditos = calculaCredito();
		this.tempoPermanencia = calculaTempoPermanencia();
	}

	public int getAnoIngresso() {
		return this.anoIngresso;
	}
	
	public int getTempoPermanencia() {
		return this.tempoPermanencia;
	}
	
	public int getQuantidadeDisciplinasAprovadas() {
		return this.quantidadeDisciplinasAprovadas;
	}
	
	public int getQuantidadeDeCreditos() {
		return this.quantidadeDeCreditos;
	}

	@Override
	public String toString() {
		return "Aluno [Nome=" + this.nome + ", Ano de Ingresso=" + this.anoIngresso + ", Tempo de Permanência: " + this.tempoPermanencia + " anos, Curso=" + this.curso
				+ ", Quantidade de Disciplinas Aprovadas=" + this.quantidadeDisciplinasAprovadas
				+ ", Créditos=" + this.quantidadeDeCreditos + "]";
	}

	
	/***************************
	 * Métodos auxiliares para calcular os créditos do aluno e o tempo de permanência.
	 * 
	 * Créditos é igual a quantidade de disciplinas aprovadas vezes 4.
	 * Tempo de Permanência é igual ao ano atual menos o ano de ingresso.
	 * 
	 **************************/
	private int calculaCredito() {
		return this.quantidadeDisciplinasAprovadas * 4;
	}

	private int calculaTempoPermanencia() {
		return LocalDate.now().getYear() - this.anoIngresso; 
	}
	
}
